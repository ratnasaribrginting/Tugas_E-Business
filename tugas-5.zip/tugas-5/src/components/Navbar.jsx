import React from "react";
import { NavLink } from "react-router-dom";

const linkStyle = {
  margin: "0 10px",
  textDecoration: "none",
  color: "black",
};

const activeStyle = {
  fontWeight: "bold",
  textDecoration: "underline",
  color: "blue",
};

export default function Navbar() {
  return (
    <nav
      style={{
        padding: "10px",
        borderBottom: "1px solid #ccc",
        marginBottom: "20px",
      }}
    >
      <NavLink to="/" style={({ isActive }) => (isActive ? activeStyle : linkStyle)}>Home</NavLink>
      <NavLink to="/about" style={({ isActive }) => (isActive ? activeStyle : linkStyle)}>About</NavLink>
      <NavLink to="/contact" style={({ isActive }) => (isActive ? activeStyle : linkStyle)}>Contact</NavLink>
      <NavLink to="/login" style={({ isActive }) => (isActive ? activeStyle : linkStyle)}>Login</NavLink>
    </nav>
  );
}
