import React from "react";

export default function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>
        Aplikasi ini dibuat untuk memenuhi tugas React Router.
      </p>
    </div>
  );
}
