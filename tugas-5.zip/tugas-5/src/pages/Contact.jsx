import React from "react";

export default function Contact() {
  return (
    <div>
      <h1>Contact</h1>
      <p>Email: <a href="mailto:example@email.com">ratna@email.com</a></p>
      <p>Instagram: <a href="https://instagram.com/" target="_blank">instagram.com/</a></p>
    </div>
  );
}
