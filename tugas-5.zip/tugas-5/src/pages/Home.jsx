import React from "react";

export default function Home() {
  return (
    <div>
      <h1>Home</h1>
      <p>Selamat datang di halaman utama aplikasi React Router</p>
    </div>
  );
}
